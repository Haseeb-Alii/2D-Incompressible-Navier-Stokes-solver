    % Record the residuals and relative residuals for this time step
    residuals(t) = resvec(end); % Taking the final residual
    relative_residuals(t) = relres(end); % Taking the final relative residual
    
    % Record the time for this time step (optional)
    times(t) = t * dt; % Assuming a constant time step size dt
    
    % Update the plot in real-time
    set(residuals_plot, 'XData', times(1:t), 'YData', residuals(1:t));
    set(relative_residuals_plot, 'XData', times(1:t), 'YData', relative_residuals(1:t));
    drawnow;