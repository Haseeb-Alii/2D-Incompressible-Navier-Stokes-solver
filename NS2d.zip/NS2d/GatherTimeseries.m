% Calculation of velocity vector 
Vm = U.^2 + V.^2; 

% Calculation of total kinetic energy
Ekin(t) = 0.5*sum(sum((Vm)*dx*dx));

%where i shows the time step
dudx = Dx(N,dx,U);
dudy = Dy(N,dy,U);
dvdx = Dx(N,dx,V);
dvdy = Dy(N,dy,V);
Diss(t) = nu.*sum(sum((dudx.^2 + dudy.^2 + dvdx.^2 + dvdy.^2)*dx*dx));
