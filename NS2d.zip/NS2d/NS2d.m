%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: Haseeb Ali
% Date: March 2024
% FILE: NS2d.m 
% The code utilizes the finite difference method i.e CD2 scheme
% to solve the incompressible Navier-Stokes equation for flow in 2d lid driven cavity.
% The code implemented Chorin projection method with pressure correction for projection 
% of intermediate velocity field onto solenoidal velcoity field
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc;

%% Preprocessing 

% set parameters 
setparameters;

% Creation of mesh
Domain;
NN = N+2;
intp = 2:NN-1;  %% Interior point indices

% Create index numbers for each grid point for velocity matrix with ghost
% points
mylist_V = 1:(NN*NN);
mygridpointlabels_V = reshape(mylist_V, NN, NN);

% Create index numbers for each grid point for pressure matrix with inner
% points

mylist = 1:N*N;
mygridpointlabels = reshape(mylist, N, N);

%%% Intialization of matrices
Intialization_matrices;

% Creating the poisson matrix
M = constructMatrixPoisson(dx,N,mygridpointlabels);
LL = ichol(-M); % peconditioner 

% Set boundary conditions
Velocity_boundary_conditions;

% Intializing the time series arrays for kinetic energy and dissipation
CreateTimeseriesArrays;


%%% Residuals log intilialization%%%%%

%Residuals_log_intialization;

%% Simulation Run
for t = 1:Nt
t

SolveNS_Euler;  %% First order explicit Euler

%SolveNS_RKC      %% Second order Runge Kutta Chebeshev projection method

%SolveNS_RK2;     %% Second order RK2 scheme   

%Residuals_log_Visualization; %% Visualize the residuals log

%VisualizeResults;  %% Visualize results 

%animation_frames; %% Storage of frames for animation


end

%% Post processing 
%animation_to_video;  %% Convert stored frames to video



%% Velocity values at only interior domain

u = U(intp,intp); 
v = V(intp,intp);


%% Save data

%save('N_128.mat',"v","u","X","Y","Ekin",'Diss',"Time")



