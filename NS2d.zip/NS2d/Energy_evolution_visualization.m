%a = load('N_128.mat')
E_K = diff(Ekin);
timestep = 1:Nt-1;
plot(timestep,abs(E_K), 'r','LineWidth',2)
hold on 
%plot(Time,abs(Diss),'k--','LineWidth',2)
%h=xlabel('Time [s]','Interpreter','latex'); set(h,'Fontsize', 14)
%legend('$\frac{dE_{kin}}{dt}$','$\chi$','interpreter','latex','FontSize',14)

%figure(2), clf;
%imagesc([0 6.3],[0 6.3],Vorticity); colormap jet; colorbar
%h=text(6.5,-0.25,'$\vec{\omega_z}$','Interpreter','latex','FontWeight','bold'); set(h,'Fontsize', 12); set(h,'Color', 'k')
%h=xlabel('X [m]','Interpreter','latex'); set(h,'Fontsize', 12)
%h=ylabel('Y [m]','Interpreter','latex'); set(h,'Fontsize', 12)
%h = title('Vorticity field at t = 0.05 s', 'Interpreter', 'latex', 'FontSize', 12);