figure(1); 

contour(X, Y, cumsum(U(intp,intp)), 30, 'Linecolor','k');
h=xlabel('X [m]','Interpreter','latex'); set(h,'Fontsize', 14);
h=ylabel('Y [m]','Interpreter','latex'); set(h,'Fontsize', 14); 
% Add text annotation for current time
    text_str = sprintf('Time: %.2f s', t * dt); % Assuming dt is your time step
    text(0.5, 1.2, text_str, 'Units', 'Normalized', 'FontSize', 12, 'Color', 'white');
    
    % Save frame every save_interval iterations
    if mod(t, save_interval) == 0
        % Capture the current figure as a frame
        frames = [frames, getframe(figure(1))];
    end

