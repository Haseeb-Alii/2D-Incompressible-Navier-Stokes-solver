%%%%%% Set the grid size and time step size over there %%%%%%%%%%%%

N = 64; % Number of grid elements 
L = 1; % Domain size
dx = L/N; % Spatial grid size
dy = dx;  
rho =  1; % density
U_lid = 1; % lid velocity
Re = 400;
nu = U_lid/Re;
% Number of time steps
dt  = 0.0002;
Simulation_time = 10*(L/U_lid);
Nt = round(Simulation_time/dt);

% Initialize an empty array to store frames
frames = [];

% Set the interval to save frames
save_interval = 20;
