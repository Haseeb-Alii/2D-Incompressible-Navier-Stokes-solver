% Open the animation video writer
animation = VideoWriter('simulation_animation.mp4', 'MPEG-4');
animation.FrameRate = 10; % Adjust frame rate as needed
open(animation);

% Write each frame to the video
for i = 1:numel(frames)
    writeVideo(animation, frames(i));
end

% Close the animation video writer
close(animation);