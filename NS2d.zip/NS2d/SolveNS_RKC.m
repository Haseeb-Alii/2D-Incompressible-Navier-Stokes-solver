% Solve NS using second order RKC scheme for time integration scheme with
% projection method
U_old = U;  V_old = V; 
P_old = P;

RKC_coefficients; % coefficients of RKC scheme

%%% First stage %%%%

% Computation of convection term
[dUconv, dVconv] = advectionSkew(N,dx,dy,U,V,intp);

% Computational of diffusion term 
dUdiff = nu.*Laplacian(N,dx,dy,U);
dVdiff = nu.*Laplacian(N,dx,dy,V);

F_ox = -dUconv + dUdiff - Dx(N,dx,P_old);
F_oy = -dVconv + dVdiff - Dy(N,dx,P_old);

Uc = U_old(intp,intp) + (mu_star1*dt).*F_ox;
Vc = V_old(intp,intp) + (mu_star1*dt).*F_oy;

U (intp,intp) = Uc; V (intp,intp) = Vc;


Velocity_boundary_conditions;

% Second stage
[dUconv, dVconv] = advectionSkew(N,dx,dy,U,V,intp);

dUdiff = nu.*Laplacian(N,dx,dy,U);
dVdiff = nu.*Laplacian(N,dx,dy,V);

F_1x = -dUconv + dUdiff - Dx(N,dx,P_old);
F_1y = -dVconv + dVdiff - Dy(N,dx,P_old);

U(intp,intp) = (1 - mu_2 - nu_2).*U_old(intp,intp) + mu_2.*Uc + nu_2.*U_old(intp,intp) + (mu_star2*dt).*F_1x + (gamma_star*dt).*F_ox;
V(intp,intp) = (1 - mu_2 - nu_2).*V_old(intp,intp) + mu_2.*Vc + nu_2.*V_old(intp,intp) + (mu_star2*dt).*F_1y + (gamma_star*dt).*F_oy;

Velocity_boundary_conditions;

[U, V, P,flag,relres,iter,resvec] = project (M,LL,U,V,U_lid,P_old,dt,N,dx,dy,intp,t);











