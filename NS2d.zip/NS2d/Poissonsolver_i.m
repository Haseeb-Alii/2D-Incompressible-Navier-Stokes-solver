function [Pcorr,flag,relres,iter,resvec] = Poissonsolver_i(M,div,N,dt,LL,t)
% pressure correction
div = div';
tic;
B = reshape(div,[],1);
[Pcorr,flag,relres,iter,resvec] = pcg((-M),B,1e-06,3000,LL,LL');
toc;
Pcorr = reshape(Pcorr, N, N);
Pcorr = Pcorr';
end