function [Pcorr,flag,relres,iter,resvec] = Poissonsolver(M,div,N,~,LL,aa_old,t)
% pressure correction
div = div';
B = reshape(div,[],1);
tic;
[Pcorr,flag,relres,iter,resvec] = pcg((-M),B,1e-06,3000,LL,LL',aa_old);
toc;
Pcorr = reshape(Pcorr, N, N);
Pcorr = Pcorr';
end
