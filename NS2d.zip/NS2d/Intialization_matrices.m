%%%% Initialization of matrices %%%%%%%%%%

% Intializing the pressure and velocity field
U =zeros(NN,NN);
V =zeros(NN,NN);
P= zeros(NN,NN);
P_old = zeros(NN,NN);