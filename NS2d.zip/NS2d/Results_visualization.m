
a = load('N_64.mat');
%{ 
figure(2), clf;
plot(DataV(:,1),DataV(:,3),'k^','MarkerFaceColor','k');
hold on
plot(a.X(64,:), a.v(64,:),'k--','LineWidth',1.5);
plot(b.X(32,:), b.v(32,:),'r--','LineWidth',1.5);
h=xlabel('X [m]','Interpreter','latex'); set(h,'Fontsize', 14);
h=ylabel('v [m/s]','Interpreter','latex'); set(h,'Fontsize', 14);
legend('Ghia et al.','Simualtion (N = 128)','Simualtion (N = 64)','Interpreter','Latex','Fontsize',10)


figure(3), clf;
plot(DataU(:,1),DataU(:,3),'k^','MarkerFaceColor','k');
hold on
plot(a.Y(:,64), a.u(:,64),'k--','LineWidth',1.5);
plot(b.Y(:,32), b.u(:,32),'r--','LineWidth',1.5);
h=xlabel('X [m]','Interpreter','latex'); set(h,'Fontsize', 14);
h=ylabel('u [m/s]','Interpreter','latex'); set(h,'Fontsize', 14);
legend('Ghia et al.','Simualtion (N = 128)','Simualtion (N = 64)','Interpreter','Latex','Fontsize',10)
%}



%{
figure;
skip=5;
X_q= X(1:skip:end, 1:skip:end);
Y_q= Y(1:skip:end, 1:skip:end);
U_q= uu(1:skip:end, 1:skip:end);
V_q= vv(1:skip:end, 1:skip:end);
% Specify arrow size (scale factor) and color
scale_factor = 3;  % Adjust this value for the desired arrow size
arrow_color = 'k';   % Change to your preferred color
quiver(X_q, Y_q,U_q,V_q, scale_factor, 'Color', arrow_color);
% Define the corner region (e.g., bottom-left corner)
corner_X = X(1:14, 1:14); % Define the region based on your grid
corner_Y = Y(1:14, 1:14);
corner_U = u(1:14, 1:14); % Subset of U velocity data for the corner
%corner_V = 1000.*v(1:14, 1:14); % Subset of V velocity data for the corner 
%contour(corner_X, corner_Y, cumsum(corner_U), 100, 'Linecolor','k');
sc = cumsum(u);
mask = sc(1:14,1:14) < 10^-04;
%filtered_matrix = sc(1:14,1:14).*mask;
%contour(X,Y,,100,'Linecolor','k');


figure;
 velocity = sqrt(a.u.^2 +a.u.^2);
% Define contour levels for the entire domain
imagesc([0 max(a.X)],[0 max(a.Y)], a.v); colorbar, colormap jet

%h=text(max(X),max(Y),'$\vec{\omega_z}(1/s)$','Interpreter','latex','FontWeight','bold'); set(h,'Fontsize', 14); set(h,'Color', 'k')
colorbar;
hold on
%contour(X, Y, cumsum(u), 10000, 'Linecolor','k');
h=xlabel('X [m]','Interpreter','latex'); set(h,'Fontsize', 14);
h=ylabel('Y [m]','Interpreter','latex'); set(h,'Fontsize', 14);

%figure;
%imagesc(velocity);
%}
figure;
velocity = sqrt(a.u.^2 +a.u.^2);
% Define contour levels for the entire domain
contourf(a.X,a.Y,curl(a.u,a.v),30); colormap jet ; colorbar
h=xlabel('X [m]','Interpreter','latex'); set(h,'Fontsize', 14);
h=ylabel('Y [m]','Interpreter','latex'); set(h,'Fontsize', 14);



