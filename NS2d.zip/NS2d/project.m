function [U, V, P,flag,relres,iter,resvec] = project (M,LL,U,V,U_lid,P_old,dt,N,dx,dy,intp,t) 

aa = P_old(intp,intp); aa = aa';

aa = reshape(aa,[],1);

%%%%% Pressure correction %%%%%%%
div = Dx(N,dx,U) + Dy(N,dy,V);

if t == 1

   [Pcorr,flag,relres,iter,resvec] = Poissonsolver_i(M,div,N,dt,LL,t);

else

    [Pcorr,flag,relres,iter,resvec] = Poissonsolver(M,div,N,dt,LL,aa,t);
end

% Pressure update

PressureBoundary_conditions;

%%%%% Velocity correction %%%%%%%%%%
Dxp = Dx(N,dx,P);
Dyp = Dy(N,dy,P);

[Us,Vs] = VelocityCorrection(U,V,Dxp,Dyp,intp);

U(intp,intp) = Us;
V(intp,intp) = Vs;

Velocity_boundary_conditions;

end