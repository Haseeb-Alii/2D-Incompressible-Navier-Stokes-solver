Ekin=zeros(Nt,1); 
Diss=zeros(Nt,1); 
Time=linspace(0,Simulation_time,Nt)';
