function dU_dy = Dy(N,dy,U)
NN = N+2;
% Interior points
dU_dy =zeros(N,N);
dU_dy(1:N,1:N) = (U(3:NN,2:NN-1) - U(1:NN-2,2:NN-1)) / (2*dy);
end
