% Cofficients of RK2 scheme
a = [1 1];
b = [0.5 0.5];