% Solve NS using second order RK-2 scheme for time integration scheme with
% projection method

U_old = U;  V_old = V; 
Uc = U;      Vc = V;
P_old = P;

Rk2_coefficients; % coefficients of RK2 scheme 

for (i=1:2)

% Computation of convection term
[dUconv, dVconv] = advectionSkew(N,dx,dy,U,V,intp);

% Computational of diffusion term 
dUdiff = nu.*Laplacian(N,dx,dy,U);
dVdiff = nu.*Laplacian(N,dx,dy,V);

dU  = -dUconv + dUdiff;
dV  = -dVconv + dVdiff;

if i==1

U(intp,intp) = U_old(intp,intp) + (dt*a(i)).*dU;
V(intp,intp) = V_old(intp,intp) + (dt*a(i)).*dV;

Velocity_boundary_conditions;

[U, V] = project (M,LL,U,V,U_lid,P_old,dt,N,dx,dy,intp,t) ;

end

Uc(intp,intp) = Uc(intp,intp) + (dt*b(i)).*dU;
Vc(intp,intp) = Vc(intp,intp) + (dt*b(i)).*dV;

end

U(intp,intp) = Uc(intp,intp);  V(intp,intp) = Vc(intp,intp);

Velocity_boundary_conditions;

[U, V, P,flag,relres,iter,resvec] = project (M,LL,U,V,U_lid,P_old,dt,N,dx,dy,intp,t);








