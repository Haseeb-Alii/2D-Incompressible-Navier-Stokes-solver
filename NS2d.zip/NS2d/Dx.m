function dU_dx = Dx (N,dx,U)
NN =  N+2;
dU_dx = zeros(N,N);
dU_dx(1:N,1:N) = (U(2:NN-1, 3:NN) - U(2:NN-1, 1:NN-2)) / (2*dx);
end


