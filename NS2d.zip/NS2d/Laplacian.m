function dd2 = Laplacian(N,dx,dy,U)
NN = N+2;
% Compute second-order x-derivative (d^2U/dx^2)
% Interior points
d2U_dx2(1:N, 1:N) = (U(2:NN-1, 3:NN) - 2*U(2:NN-1, 2:NN-1) + U(2:NN-1, 1:NN-2)) / (dx^2);


% Compute second-order y-derivative (d^2U/dy^2)

% Interior points
d2U_dy2(1:N, 1:N) = (U(3:NN,2:NN-1) - 2*U(2:NN-1, 2:NN-1) + U(1:NN-2,2:NN-1)) / (dx^2);

dd2 = d2U_dx2 + d2U_dy2;

end