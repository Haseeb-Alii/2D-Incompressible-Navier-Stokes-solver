% Coefficients of RKC scheme calcualyed using analytical realtion for
% Chebeshev polyomial of order n here n = 2
ep = 2/13;
w_o = 1+ ep/4 ;
T_x2 = 4*w_o - 1;
T_xx2 = 3;
w_1 = T_x2/T_xx2;
b_2 = T_xx2/(T_x2)^2;
b_o = b_2;
b_1 = b_2;
mu_star1 = b_1*w_1;
mu_2 = (2*b_2*w_o)/b_1;
nu_2 = -b_2/b_o;
mu_star2 = (2*b_2*w_1)/b_1;
gamma_star = -1*(1-b_1*w_o)*mu_star2;


