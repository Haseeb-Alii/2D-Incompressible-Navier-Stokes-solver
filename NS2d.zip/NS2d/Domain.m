% Mesh creation
in = 1:N;
x = (in - 0.5)*dx;
y = (in - 0.5)*dy;
[X, Y] = meshgrid(x, y);