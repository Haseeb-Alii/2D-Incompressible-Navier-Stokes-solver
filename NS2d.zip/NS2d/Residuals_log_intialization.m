% Preallocate arrays to store residuals and relative residuals
residuals = zeros(Nt, 1);
relative_residuals = zeros(Nt, 1);
times = zeros(Nt, 1);

% Create a figure and axes for plotting
figure;
subplot(2, 1, 1);
residuals_plot = plot(0, 0, 'b.-');
title('Residuals vs Time');
legend('P-residuals')
xlabel('Time');
ylabel('Residual');
grid on;

subplot(2, 1, 2);
relative_residuals_plot = plot(0, 0, 'r.-');
title('Relative Residuals vs Time');
xlabel('Time');
legend('P-residuals')
ylabel('Relative Residual');
grid on;