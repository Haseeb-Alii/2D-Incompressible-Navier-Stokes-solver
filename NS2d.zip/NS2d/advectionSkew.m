function [dUconv, dVconv] = advectionSkew(N,dx,dy,U,V,intp)

NN = N+2;

uu = U.*U;
vv = V.*V;
uv = U.*V; 
vu = V.*U;

dux = Dx(N,dx,U);
duy=  Dy(N,dy,U);
dVx = Dx(N,dx,V);
dVy=  Dy(N,dy,V);

duux = Dx(N,dx,uu);
duvy = Dy(N,dx,vu);
duvx = Dx(N,dx,uv);
dvvy = Dy(N,dx,vv);


dUconv = 0.5.*( U(intp,intp).*dux + V(intp,intp).*duy + duux + duvy);
dVconv = 0.5.*( U(intp,intp).*dVx + V(intp,intp).*dVy + duvx + dvvy);

end