NN = N+2;

% Pressure boundary conditions
P(2:NN-1,2:NN-1)= Pcorr;
P(intp,NN)= P(intp,NN-1);  % Right wall Nuemann boundary condition
P(intp,1)=  P(intp,2);     % left wall Nuemann boundary condition
P(NN,intp)= P(NN-1,intp);  % Top wall  Nuemnann boundary condition
P(1,intp)= P(2,intp); % Bottom wall Nuemann boundary condition
P(1,round(NN/2))= -P(2,round(NN/2)); % Bottom wall Nuemann boundary condition



