% Visualize results
figure(1), clf, box
contour(X,Y,cumsum(U(intp,intp)),50)
h = title('u velocity'); set(h, 'Fontsize',20)
axis([0.01, L-0.01, 0.01, L-0.01]), axis tight
axis off, axis equal
drawnow
colorbar

% Define the target y value
target_y = 0.50;


% Extract the corresponding row from the U matrix
V_row = V(65, :);

% Interpolate the values along the row at the desired x location
target_x = 0.50; % Define the target x value
V_at_target = interp1(X(64, :), V_row(intp), target_x);
