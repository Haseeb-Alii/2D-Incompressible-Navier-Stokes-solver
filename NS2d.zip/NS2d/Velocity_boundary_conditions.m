% Velocity boundary conditions 
U(1,intp)= -U(2,intp); % Bottom wall
U(NN,intp)= 2*U_lid - U((NN-1),intp); % Top wall
U(intp,1)= -U(intp,2); % Left wall
U(intp,NN)= -U(intp,(NN-1)); % Right wall 

V(1,intp)= -V(2,intp); % Bottom wall
V(NN,intp)= -V((NN-1),intp); % Top wall
V(intp,1)= -V(intp,2); % Left wall
V(intp,NN)= -V(intp,(NN-1)); % Right wall 
