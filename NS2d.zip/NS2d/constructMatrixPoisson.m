function M =  constructMatrixPoisson(dx,N,mygridpointlabels)
M = sparse(N*N, N*N);
% Fill in the matrix element
for j = 1:N
    for i = 1:N
        index = mygridpointlabels(i, j);
        if i == 1 && j == 1     % Lower left corner boundary condition
            M(index, index) = -2;
            M(index, mygridpointlabels(i, j+1)) = 1;
            M(index, mygridpointlabels(i+1, j)) = 1;
        elseif i == N && j == 1 % Lower right corner boundary condition
            M(index, index) = -2;
            M(index, mygridpointlabels(i, j+1)) = 1;
            M(index, mygridpointlabels(i-1, j)) = 1;
        elseif i == 1 && j == N % Upper left corner boundary condition
            M(index, index) = -2;
            M(index, mygridpointlabels(i, j-1)) = 1;
            M(index, mygridpointlabels(i+1, j)) = 1;
        elseif i == N && j == N % Upper right corner boundary condition
            M(index, index) = -2;
            M(index, mygridpointlabels(i, j-1)) = 1;
            M(index, mygridpointlabels(i-1, j)) = 1;
        elseif any(i==2:N-1) && j == 1 % Bottom wall
            M(index, index) = -3;
            M(index, mygridpointlabels(i+1, j)) = 1;
            M(index, mygridpointlabels(i-1, j)) = 1;
            M(index, mygridpointlabels(i, j+1)) = 1;
         
        elseif any(i==N/2) && j == 1 % Bottom wall
            M(index, index) = -5;
            M(index, mygridpointlabels(i+1, j)) = 1;
            M(index, mygridpointlabels(i-1, j)) = 1;
            M(index, mygridpointlabels(i, j+1)) = 1;

        elseif any(i==2:N-1) && j == N % Top wall
            M(index, index) = -3;
            M(index, mygridpointlabels(i, j-1)) = 1;
            M(index, mygridpointlabels(i+1, j)) = 1;
            M(index, mygridpointlabels(i-1, j)) = 1;
        elseif i == 1 && any(j==2:N-1) % Left wall
            M(index, index) = -3;
            M(index, mygridpointlabels(i, j-1)) = 1;
            M(index, mygridpointlabels(i+1, j)) = 1;
            M(index, mygridpointlabels(i, j+1)) = 1;
        elseif i == N && any(j==2:N-1) % Right wall
            M(index, index) = -3;
            M(index, mygridpointlabels(i, j-1)) = 1;
            M(index, mygridpointlabels(i-1, j)) = 1;
            M(index, mygridpointlabels(i, j+1)) = 1;
        elseif any(i==2:N-1) && any(j==2:N-1) % Interior points
            M(index, index) = -4;
            M(index, mygridpointlabels(i, j-1)) = 1;
            M(index, mygridpointlabels(i-1, j)) = 1;
            M(index, mygridpointlabels(i+1, j)) = 1;
            M(index, mygridpointlabels(i, j+1)) = 1;
        end
    end
end
M = (1/dx^2).*(M);
end