
U_old = U;  V_old = V;

% Computation of convection term
[dUconv, dVconv] = advectionSkew(N,dx,dy,U,V,intp);
dUdiff = nu.*Laplacian(N,dx,dy,U);
dVdiff = nu.*Laplacian(N,dx,dy,V);
dU = -dUconv + dUdiff;
dV = -dVconv + dVdiff; 

U(intp,intp) = U_old(intp,intp) + dt.*dU;
V(intp,intp) = V_old(intp,intp) + dt.*dV;

Velocity_boundary_conditions;

[U, V] = project (M,LL,U,V,U_lid,P_old,dt,N,dx,dy,intp,t) ;